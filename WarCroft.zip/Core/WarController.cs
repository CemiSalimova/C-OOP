﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WarCroft.Constants;
using WarCroft.Entities.Characters.Contracts;
using WarCroft.Entities.Characters.Entities;
using WarCroft.Entities.Items;

namespace WarCroft.Core
{
    public class WarController
    {
        private List<Character> players;
        private List<Character> deadPlayers;
        private Stack<Item> itemPool;
        private string itemName;
        public WarController()
        {
            players = new List<Character>();
            itemPool = new Stack<Item>();
            deadPlayers = new List<Character>();
        }

        public string JoinParty(string[] args)
        {
            Character player = null;

            if (args[0] == nameof(Warrior))
            {
                player = new Warrior(args[1]);
            }
            else if (args[0] == nameof(Priest))
            {
                player = new Priest(args[1]);
            }
            else
            {
                throw new ArgumentException(String.Format(ExceptionMessages.InvalidCharacterType, args[0]));
            }
            players.Add(player);
            return $"{String.Format(SuccessMessages.JoinParty, player.Name)}";
        }

        public string AddItemToPool(string[] args)
        {
            itemName = args[0];
            Item item = null;
            if (itemName == nameof(FirePotion))
            {
                item = new FirePotion();
            }
            else if (itemName == nameof(HealthPotion))
            {
                item = new HealthPotion();
            }
            else
            {
                throw new ArgumentException(String.Join(ExceptionMessages.InvalidItem, itemName));
            }
            itemPool.Push(item);
            return $"{String.Format(SuccessMessages.AddItemToPool, item.GetType().Name)}";
        }

        public string PickUpItem(string[] args)
        {
            string characterName = args[0];
            var targetCharacter = players.FirstOrDefault(ch => ch.Name == characterName);
            if (targetCharacter == null)
            {
                throw new ArgumentException(String.Format(ExceptionMessages.CharacterNotInParty, characterName));
            }
            if (itemPool.All(t => t == null))
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.ItemPoolEmpty));
            }

            var addedItem = itemPool.Pop();
            targetCharacter.Bag.AddItem(addedItem);
            return $"{String.Format(SuccessMessages.PickUpItem, targetCharacter.Name, addedItem.GetType().Name)}";
        }

        public string UseItem(string[] args)
        {
            string characterName = args[0];
            string itemName = args[1];
            var targetCharacter = players.FirstOrDefault(ch => ch.Name == characterName);
            var targetItem = targetCharacter.Bag.Items.FirstOrDefault(i => i.GetType().Name == itemName);
            if (targetCharacter == null)
            {
                throw new ArgumentException(ExceptionMessages.CharacterNotInParty, characterName);
            }
            if (targetCharacter.Bag.Items.All(i => i == null))
            {
                throw new InvalidOperationException(ExceptionMessages.EmptyBag);
            }
            if (targetCharacter.Bag.Items.FirstOrDefault(i => i.GetType().Name == itemName) == null)
            {
                throw new ArgumentException(String.Format(ExceptionMessages.ItemNotFoundInBag, itemName));
            }

            if (targetCharacter.GetType().Name == nameof(Warrior))
            {
                (targetCharacter as Warrior).Bag.GetItem(itemName);
                targetItem.AffectCharacter(targetCharacter);
            }
            else if (targetCharacter.GetType().Name == nameof(Priest))
            {
                (targetCharacter as Priest).Bag.GetItem(itemName);
                targetItem.AffectCharacter(targetCharacter);
            }

            return $"{String.Format(SuccessMessages.UsedItem, targetCharacter.Name, itemName)}";
        }

        public string GetStats()
        {
            StringBuilder sb = new StringBuilder();

            foreach (var player in players.OrderByDescending(p => p.IsAlive).ThenByDescending(p => p.Health))
            {
                sb.AppendLine(player.ToString());
            }
            return sb.ToString().TrimEnd();
        }

        public string Attack(string[] args)
        {
            string attackerName = args[0];
            string receiverName = args[1];
            var targetAttacker = players.FirstOrDefault(ch => ch.Name == attackerName);
            var targetReceiver = players.FirstOrDefault(ch => ch.Name == receiverName);
            if (targetAttacker == null)
            {
                throw new ArgumentException(String.Format(ExceptionMessages.CharacterNotInParty, attackerName));
            }
            if (targetReceiver == null)
            {
                throw new ArgumentException(String.Format(ExceptionMessages.CharacterNotInParty, receiverName));
            }
            if (targetAttacker.GetType().Name != nameof(Warrior))
            {
                throw new ArgumentException(String.Format(ExceptionMessages.AttackFail, attackerName));
            }
            if (targetAttacker.IsAlive)
            {
                if (deadPlayers.FirstOrDefault(t => t == targetReceiver) != null)
                {
                    targetReceiver.EnsureAlive();
                }
                (targetAttacker as Warrior).Attack(targetReceiver);
                if (targetReceiver.IsAlive)
                {
                    return $"{String.Format(SuccessMessages.AttackCharacter, targetAttacker.Name, targetReceiver.Name, targetAttacker.AbilityPoints, targetReceiver.Name, targetReceiver.Health, targetReceiver.BaseHealth, targetReceiver.Armor, targetReceiver.BaseArmor)}";
                }
                else
                {
                    deadPlayers.Add(targetReceiver);
                    return $"{String.Format(SuccessMessages.AttackCharacter, targetAttacker.Name, targetReceiver.Name, targetAttacker.AbilityPoints, targetReceiver.Name, targetReceiver.Health, targetReceiver.BaseHealth, targetReceiver.Armor, targetReceiver.BaseArmor)}" + "\n" +
                       $"{String.Format(SuccessMessages.AttackKillsCharacter, targetReceiver.Name)}";
                }

            }
            else
            {
                return $"{String.Format(ExceptionMessages.AffectedCharacterDead)}";
            }
        }

        public string Heal(string[] args)
        {
            string healerName = args[0];
            string healingReceiverName = args[1];

            var targetHealer = players.FirstOrDefault(ch => ch.Name == healerName);
            var targetReceiver = players.FirstOrDefault(ch => ch.Name == healingReceiverName);
            if (targetHealer == null)
            {
                throw new ArgumentException(String.Format(ExceptionMessages.CharacterNotInParty, healerName));
            }
            if (targetReceiver == null)
            {
                throw new ArgumentException(String.Format(ExceptionMessages.CharacterNotInParty, healingReceiverName));
            }
            if (deadPlayers.FirstOrDefault(t => t == targetReceiver) != null)
            {
                targetReceiver.EnsureAlive();
            }
            if (targetHealer.GetType().Name != nameof(Priest))
            {
                throw new ArgumentException(String.Format(ExceptionMessages.HealerCannotHeal, healerName));
            }
            if (!targetHealer.IsAlive)
            {
                return $"{String.Format(ExceptionMessages.AffectedCharacterDead)}";
            }
            else
            {
                (targetHealer as Priest).Heal(targetReceiver);
                return $"{String.Format(SuccessMessages.HealCharacter, targetHealer.Name, targetReceiver.Name, targetHealer.AbilityPoints, targetReceiver.Name, targetReceiver.Health, targetReceiver.BaseHealth)}";
            }
        }
    }
}
