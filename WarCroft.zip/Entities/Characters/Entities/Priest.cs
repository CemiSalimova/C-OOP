﻿using System;
using System.Collections.Generic;
using System.Text;
using WarCroft.Constants;
using WarCroft.Entities.Characters.Contracts;
using WarCroft.Entities.Inventory.Entities;

namespace WarCroft.Entities.Characters.Entities
{
    public class Priest : Character, IHealer
    {
        
       

        public Priest(string name)
            : base(name, 50, 25, 40,new Backpack())
        {
           
        }
       
        public void Heal(Character character)
        {
            if(this.IsAlive && character.IsAlive)
            {
                if (this.Name == character.Name)
                {
                    throw new InvalidOperationException(String.Format(ExceptionMessages.HealerCannotHeal,character.Name));
                }
                character.Health += this.AbilityPoints;
            }
        }
    }
}
