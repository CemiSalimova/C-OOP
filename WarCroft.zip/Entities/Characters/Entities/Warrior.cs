﻿using System;
using System.Collections.Generic;
using System.Text;
using WarCroft.Constants;
using WarCroft.Entities.Characters.Contracts;
using WarCroft.Entities.Inventory.Entities;

namespace WarCroft.Entities.Characters.Entities
{
    public class Warrior : Character, IAttacker
    {
        
        private const double abilityPoints = 40;

        public Warrior(string name) 
            : base(name, 100, 50, abilityPoints, new Satchel())
        {
        }

        public void Attack(Character character)
        {
            if (this.IsAlive&&character.IsAlive)
            {
                if (this.Name == character.Name)
                {
                    throw new InvalidOperationException(ExceptionMessages.CharacterAttacksSelf);
                }
                character.TakeDamage(this.AbilityPoints);
            }
           
        }
    }
}
