﻿using System;

using WarCroft.Constants;
using WarCroft.Entities.Inventory.Entities;
using WarCroft.Entities.Items;

namespace WarCroft.Entities.Characters.Contracts
{
    public abstract class Character
    {
		// TODO: Implement the rest of the class.
		private string  name;
		private double  baseHealth;
		private double baseArmor;
		private double  armor;
		private double  abilityPoints;
		//private Bag bag;
		private double health;
		//private double MIN_HEALTH;
		//private double MAX_HEALTH;
		//private double MIN_ARMOR;

		public Character(string name, double baseHealth, double baseArmor, double abilityPoints, Bag bag)
		{
			this.BaseHealth = baseHealth;
			this.health = baseHealth;
			this.Name = name;
			this.BaseArmor = baseArmor;
			this.armor = baseArmor;
			this.AbilityPoints = abilityPoints;
			this.Bag = bag;
		}
		public string Name
		{
			get { return this.name; }
			set
			{
				if (string.IsNullOrWhiteSpace(value))
				{
					throw new ArgumentException(ExceptionMessages.CharacterNameInvalid);
				}
				this.name = value;
			} 
		}
		public double BaseHealth 
		{
			get => this.baseHealth;
			set
			{
				this.baseHealth = value;
			}
		}
		public double Health
		{
			get
			{
				if (this.health<=this.baseHealth&&this.health>=0)
				{
					return this.health;
				}
				return 0;
			}
			set
			{
				this.health = value;
			}
		} 
		public double BaseArmor
		{ 
			get=>this.baseArmor;
			set
			{
			this.baseArmor = value;
			} 
		}
		public double Armor
		{
			
			get
			{
				if (this.armor<0)
				{
					return 0;
				}
				return this.armor;
			}
			private set => this.armor=value;
		}
		public double AbilityPoints { get=>this.abilityPoints; private set=>this.abilityPoints=value; }
		public Bag Bag { get; }
		public bool IsAlive { get; set; } = true;

		public void EnsureAlive()
		{
			if (!this.IsAlive)
			{
				throw new InvalidOperationException(ExceptionMessages.AffectedCharacterDead);
			}
		}
		public void TakeDamage(double hitPoints)
		{
			if (IsAlive&&Health>=0)
			{
				if (Armor-hitPoints<0)
				{
					Health -= Math.Abs(Armor - hitPoints);
				}
				this.Armor-= hitPoints;
				if (Health<=0)
				{
					IsAlive = false;

				}
			}

		}
		public void UseItem(Item item)
		{
			if (IsAlive)
			{
				Bag.AddItem(item);
			}
		}
		public override string ToString()
		{
			var DeadOrLive ="";
			if (IsAlive)
			{
				DeadOrLive = "Alive";
			}
			else
			{
				DeadOrLive = "Dead";
			}
			return $"{name} - HP: {Health}/{BaseHealth}, AP: {Armor}/{BaseArmor}, Status: {DeadOrLive}";
		}

	}
}